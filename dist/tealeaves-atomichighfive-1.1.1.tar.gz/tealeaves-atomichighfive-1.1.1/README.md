# Installation
`pip install git+git://github.com/atomichighfive/tealeaves`
