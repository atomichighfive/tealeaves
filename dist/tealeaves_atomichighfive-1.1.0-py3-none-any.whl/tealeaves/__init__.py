import holoviews as hv
print('Using bokeh for rendering. Change this with util.set_backend.')
hv.extension('bokeh')
