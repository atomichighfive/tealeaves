from typing import Tuple

import numpy as np
import pandas as pd
import holoviews as hv
from holoviews import opts
import bokeh

# Local imports
from tealeaves.util.histogram_bin_formulas import bin_it

hv.extension('bokeh')

# Local imports
from tealeaves.util.histogram_bin_formulas import bin_it

def dist_compare_plot(seq1, seq2, bins=None, max_bar_categories:int=40):
    plot_object = None
    if np.issubdtype(seq1, np.number) and \
    np.issubdtype(seq2, np.number) and \
    len(np.unique(np.concatenate((seq1, seq2)))) > 4:
        if bins is None:
            bins = bin_it(np.concatenate((seq1.values, seq2.values), axis=0))
        frequencies1, edges1 = np.histogram(seq1.dropna(), bins, density=True)
        frequencies2, edges2 = np.histogram(seq2.dropna(), bins, density=True)
        plot_object = hv.NdOverlay({
            'df1':hv.Histogram((edges1, frequencies1)),
            'df2':hv.Histogram((edges2, frequencies2))
        })
        plot_object.opts('Histogram',fill_alpha=0.5).redim.label(x='Value')
    else:
        plot_df_1 = pd.DataFrame(seq1.value_counts()/len(seq1))
        plot_df_1["Data frame"] = "df1"
        plot_df_2 = pd.DataFrame(seq2.value_counts()/len(seq2))
        plot_df_2["Data frame"] = "df2"
        plot_df = pd.concat([plot_df_1, plot_df_2]).reset_index()
        plot_df.columns = ['Category', 'Count', 'Source']
        if len(plot_df.Category.unique()) < max_bar_categories:
            plot_object = hv.Bars(plot_df, ['Category', 'Source'], 'Count')
        else:
            train_levels = plot_df_1.index.unique()
            test_levels = plot_df_2.index.unique()
            plot_object = hv.Bars(
                (["Only df1", "In both", "Only df2"],
                 [
                    len([t for t in train_levels if t not in test_levels]),
                    len([t for t in train_levels if t in test_levels]),
                    len([t for t in test_levels if t not in train_levels])
                ]),
            ).opts(invert_axes=True)
    return plot_object


def dist_compare_grid(df1, df2, max_bar_categories:int=40, grid_size:Tuple[int,int]=(900,900)):
    columns = [c for c in df1.columns if c in df2.columns]
    grid_cols = int(np.ceil(np.sqrt(len(columns))))
    grid_rows = int(np.ceil(len(columns)/grid_cols))
    plots = [dist_compare_plot(df1[c], df2[c], max_bar_categories).opts(title=c) for c in columns]
    grid = hv.Layout(plots).opts(shared_axes=False, normalize=False)
    grid.cols(grid_cols)
    # set sizes
    subplot_size = (int(grid_size[0]/grid_cols), int(grid_size[1]/grid_rows))
    grid.opts(
        opts.Histogram(width=subplot_size[0],height=subplot_size[1]),
        opts.Bars(width=subplot_size[0],height=subplot_size[1])
    )
    return grid
