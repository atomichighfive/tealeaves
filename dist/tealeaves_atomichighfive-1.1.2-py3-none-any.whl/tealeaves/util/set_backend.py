import holoviews as hv

def set_backend(backend):
    hv.extension(backend)
